#ifndef HEART_RATE_SENSOR_H
#define HEART_RATE_SENSOR_H

class heartRateSensor {
  public:
    heartRateSensor();    // Default constructor
    void begin();         // Initialise sensor
    int getReading();     // Get heart rate
};

#endif