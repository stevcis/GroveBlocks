#define SDA_PORT PORTD
#define SDA_PIN 3
#define SCL_PORT PORTD
#define SCL_PIN 2

#include "heartRateSensor.h"
#include <SoftWire.h>          // Include this so you can use `Wire`

// ❌ REMOVE this line:
// SoftWire Wire = SoftWire();    // Already declared globally by SoftWire.h

heartRateSensor::heartRateSensor() {
  // nothing
}

void heartRateSensor::begin() {
  Wire.begin();  // Use the global one
}

int heartRateSensor::getReading() {
  Wire.requestFrom(0xA0 >> 1, 1);  // 0x50
  if (Wire.available()) {
    return Wire.read();
  }
  return -1;
}

