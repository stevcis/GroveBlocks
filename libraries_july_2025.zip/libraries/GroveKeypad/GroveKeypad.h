#ifndef _GROVE_KEYPAD_H_
#define _GROVE_KEYPAD_H_

#include <Arduino.h>
#include <SoftwareSerial.h>

class GroveKeypad {
public:
  GroveKeypad(uint8_t rx, uint8_t tx);
  void   begin(uint32_t baud = 9600);
  void   checkAndUpdate();      // reads digits only (0–9)

  bool   hashPressed() const;   // true if # was pressed last cycle
  bool   starPressed() const;   // true if * was pressed last cycle

  String read() const;          // returns the current digit string
  void   backspace();           // remove last digit
  void   clear();               // reset sequence

  static const uint8_t MAX_LEN = 8;

private:
  char mapByte(uint8_t);
  SoftwareSerial _ss;
  String _current;
  bool _hashFlag, _starFlag;
};

#endif
