#include "GroveKeypad.h"

static const uint8_t MAP_BYTES[12] = {
  0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEB,0xEA,0xEC};
static const char    MAP_ASCII[12] = {
  '1','2','3','4','5','6','7','8','9','0','*','#'};

GroveKeypad::GroveKeypad(uint8_t rx, uint8_t tx)
  : _ss(rx, tx), _hashFlag(false), _starFlag(false) {}

void GroveKeypad::begin(uint32_t baud) {
  _ss.begin(baud);
}

void GroveKeypad::checkAndUpdate() {
  _hashFlag = false;
  _starFlag = false;

  while (_ss.available()) {
    char key = mapByte(_ss.read());
    if (!key) continue;

    if (key >= '0' && key <= '9') {
      if (_current.length() < MAX_LEN)
        _current += key;
    } else if (key == '*') {
      _starFlag = true;
    } else if (key == '#') {
      _hashFlag = true;
    }
  }
}

bool GroveKeypad::hashPressed() const {
  return _hashFlag;
}

bool GroveKeypad::starPressed() const {
  return _starFlag;
}

String GroveKeypad::read() const {
  return _current;
}

void GroveKeypad::backspace() {
  if (_current.length())
    _current.remove(_current.length() - 1);
}

void GroveKeypad::clear() {
  _current = "";
}

char GroveKeypad::mapByte(uint8_t b) {
  for (uint8_t i = 0; i < 12; ++i)
    if (b == MAP_BYTES[i]) return MAP_ASCII[i];
  return 0;
}
