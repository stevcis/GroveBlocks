#ifndef MY_ATOMISER_H
#define MY_ATOMISER_H
#include <Arduino.h>
class Atomiser {
  
  private:
    byte pin;
    
  public:
    Led(byte pin);
    void init();
    void on();
    void off();
};
#endif