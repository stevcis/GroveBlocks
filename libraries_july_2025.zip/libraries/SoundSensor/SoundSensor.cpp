#include "SoundSensor.h"
SoundSensor::SoundSensor(byte pin) {
  this->pin = pin;
  init();
}

void SoundSensor::init() {
  pinMode(pin, INPUT);
}

float SoundSensor::getReading() {
	int sensor_value = analogRead(pin);
    return sensor_value;
}
