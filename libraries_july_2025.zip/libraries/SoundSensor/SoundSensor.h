#ifndef MY_SOUNDSENSOR_H
#define MY_SOUNDSENSOR_H
#include <Arduino.h>
class SoundSensor {
  
  private:
    byte pin;
    
  public:
    SoundSensor(byte pin);
    void init();
    float getReading();
};
#endif