#ifndef MY_MOSFET_H
#define MY_MOSFET_H
#include <Arduino.h>
class Mosfet {
  
  private:
    byte pin;
    
  public:
    Mosfet(byte pin);
    void init();
    void on();
    void off();
};
#endif