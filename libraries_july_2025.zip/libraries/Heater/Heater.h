#ifndef MY_HEATER_H
#define MY_HEATER_H
#include <Arduino.h>
class Heater {
  
  private:
    byte pin;
    
  public:
    Heater(byte pin);
    void init();
    void on();
    void off();
};
#endif