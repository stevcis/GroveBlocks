// #ifndef BRACCIO_CONTROL_H
// #define BRACCIO_CONTROL_H

// #include <Arduino.h>
// #include <Wire.h>

// #define BRACCIO_I2C_ADDR 8  // I2C address of the Braccio Slave

// class BraccioControl {
// public:
//     void begin();
//     void go_tall(int base);
//     void pick_up_at(int base);
//     void drop_at(int base);
//     void rotate_to(int base);

// private:
//     void sendCommand(uint8_t command);  // Use uint8_t consistently
//     void waitForAck();
// };

// #endif

#ifndef BRACCIOCONTROL_H
#define BRACCIOCONTROL_H

#include <Wire.h>
#include <Arduino.h>

#define BRACCIO_I2C_ADDR 8  // I2C address of the Braccio slave

class BraccioControl {
public:
    void begin();
    void go_tall(int base);
    void pick_up_at(int base);
    void drop_at(int base);
    void rotate_to(int base);
    void push_at(int base);
    
private:
    void sendCommand(uint8_t command);
};

#endif
