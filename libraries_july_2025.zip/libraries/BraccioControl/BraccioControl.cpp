#include "BraccioControl.h"
#include <Wire.h>
#include <Arduino.h>

#define BRACCIO_I2C_ADDR 8  // Slave address

void BraccioControl::begin() {
    Wire.begin();
}

void BraccioControl::sendCommand(uint8_t command) {
    Wire.beginTransmission(BRACCIO_I2C_ADDR);
    Wire.write(command);
    Wire.endTransmission();
}

void BraccioControl::go_tall(int base) {
    sendCommand(base / 45 + 1);
    delay(3000);  // Adjust as needed (5000)
}

void BraccioControl::pick_up_at(int base) {
    sendCommand(base / 45 + 6);
    delay(10000);  // Adjust as needed (200000)
}

void BraccioControl::drop_at(int base) {
    sendCommand(base / 45 + 11);
    delay(3000);  // Adjust as needed (9000)
}

void BraccioControl::rotate_to(int base) {
    sendCommand(base / 45 + 16);
    delay(6000);  // Adjust as needed
}

void BraccioControl::push_at(int base) {
    sendCommand(base / 45 + 21);
    delay(15000);  // Adjust as needed
}



// #include "BraccioControl.h"

// void BraccioControl::begin() {
//     Wire.begin();
// }

// void BraccioControl::sendCommand(uint8_t command) {  // Match uint8_t with .h file
//     Wire.beginTransmission(BRACCIO_I2C_ADDR);
//     Wire.write(command);
//     Wire.endTransmission();
//     waitForAck();  // Wait for acknowledgment before continuing
// }

// void BraccioControl::waitForAck() {
//     unsigned long startTime = millis();
//     while (millis() - startTime < 5000) {  // 5-second timeout
//         Wire.requestFrom(BRACCIO_I2C_ADDR, 1);
//         if (Wire.available()) {
//             uint8_t response = Wire.read();
//             if (response == 250) return;  // Acknowledgment received
//         }
//         delay(50);
//     }
//     Serial.println("⚠️ Warning: No response from Braccio within timeout period!");
// }

// void BraccioControl::go_tall(int base) {
//     uint8_t command = base / 45 + 1;
//     sendCommand(command);
// }

// void BraccioControl::pick_up_at(int base) {
//     uint8_t command = base / 45 + 6;
//     sendCommand(command);
// }

// void BraccioControl::drop_at(int base) {
//     uint8_t command = base / 45 + 11;
//     sendCommand(command);
// }

// void BraccioControl::rotate_to(int base) {
//     uint8_t command = base / 45 + 16;
//     sendCommand(command);
// }




// #include "BraccioControl.h"

// void BraccioControl::begin() {
//     Wire.begin();
// }

// void BraccioControl::sendCommand(uint8_t command) {
//     Wire.beginTransmission(BRACCIO_I2C_ADDR);
//     Wire.write(command);
//     Wire.endTransmission();

//     // ✅ Now we wait inside this function until the slave confirms completion.
//     waitForAck();
// }

// void BraccioControl::waitForAck() {
//     unsigned long startTime = millis();
//     bool waiting_acknowledgement = true;

//     while (waiting_acknowledgement && (millis() - startTime < 30000)) { // Max wait time: 30 sec
//         if (Wire.available()) {  // ✅ Only check if data was received
//             uint8_t response = Wire.read();
//             if (response == 250) {  // ✅ Slave confirms completion
//                 Serial.println("✅ Braccio Acknowledged Command");
//                 waiting_acknowledgement = false;
//             }
//         }
//         delay(100); // Small delay to avoid excessive CPU usage
//     }

//     if (waiting_acknowledgement) {
//         Serial.println("⚠️ ERROR: No ACK received from Braccio within 30 sec!");
//     }
// }

// // Movement functions
// void BraccioControl::go_tall(int base) {
//     uint8_t command = base / 45 + 1;
//     sendCommand(command);
// }

// void BraccioControl::pick_up_at(int base) {
//     uint8_t command = base / 45 + 6;
//     sendCommand(command);
// }

// void BraccioControl::drop_at(int base) {
//     uint8_t command = base / 45 + 11;
//     sendCommand(command);
// }

// void BraccioControl::rotate_to(int base) {
//     uint8_t command = base / 45 + 16;
//     sendCommand(command);
// }


