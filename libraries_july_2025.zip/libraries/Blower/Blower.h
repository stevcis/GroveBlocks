#ifndef MY_BLOWER_H
#define MY_BLOWER_H
#include <Arduino.h>
class Blower {
  
  private:
    byte pin;
    
  public:
    Blower(byte pin);
    void init();
    void on();
    void off();
};
#endif