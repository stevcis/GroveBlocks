#include "LightSensor.h"
LightSensor::LightSensor(byte pin) {
  this->pin = pin;
  init();
}

void LightSensor::init() {
  pinMode(pin, INPUT);
}

float LightSensor::getReading() {
	int sensor_value = analogRead(pin);
    return sensor_value;
}
