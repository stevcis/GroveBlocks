#ifndef MY_LIGHTSENSOR_H
#define MY_LIGHTSENSOR_H
#include <Arduino.h>
class LightSensor {
  
  private:
    byte pin;
    
  public:
    LightSensor(byte pin);
    void init();
    float getReading();
};
#endif