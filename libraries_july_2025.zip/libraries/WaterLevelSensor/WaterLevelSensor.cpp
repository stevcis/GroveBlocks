#include "WaterLevelSensor.h"
#include <Wire.h>

#define THRESHOLD 100

WaterLevelSensor::WaterLevelSensor() {
  memset(low_data, 0, sizeof(low_data));
  memset(high_data, 0, sizeof(high_data));
}

void WaterLevelSensor::begin() {
  Wire.begin();
}

void WaterLevelSensor::getLow8() {
  memset(low_data, 0, sizeof(low_data));
  Wire.requestFrom(LOW_ADDR, (uint8_t)8);
  while (Wire.available() < 8);
  for (int i = 0; i < 8; i++) {
    low_data[i] = Wire.read();
  }
  delay(10);
}

void WaterLevelSensor::getHigh12() {
  memset(high_data, 0, sizeof(high_data));
  Wire.requestFrom(HIGH_ADDR, (uint8_t)12);
  while (Wire.available() < 12);
  for (int i = 0; i < 12; i++) {
    high_data[i] = Wire.read();
  }
  delay(10);
}

int WaterLevelSensor::getReading() {
  getLow8();
  getHigh12();

  uint32_t touch_val = 0;
  uint8_t trig_section = 0;

  for (int i = 0; i < 8; i++) {
    if (low_data[i] > THRESHOLD) {
      touch_val |= 1 << i;
    }
  }

  for (int i = 0; i < 12; i++) {
    if (high_data[i] > THRESHOLD) {
      touch_val |= (uint32_t)1 << (8 + i);
    }
  }

  while (touch_val & 0x01) {
    trig_section++;
    touch_val >>= 1;
  }

  return trig_section * 5;  // returns 0–100 (%)
}
