#ifndef MY_WATERLEVELSENSOR_H
#define MY_WATERLEVELSENSOR_H

#include <Arduino.h>

class WaterLevelSensor {
  public:
    WaterLevelSensor();
    void begin();               // starts Wire
    int getReading();           // returns water level 0–100 (%)

  private:
    void getLow8();
    void getHigh12();

    static const uint8_t LOW_ADDR  = 0x77;
    static const uint8_t HIGH_ADDR = 0x78;

    uint8_t low_data[8];
    uint8_t high_data[12];
};

#endif
