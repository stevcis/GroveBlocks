#include "TDS_Sensor.h"
#include <math.h>

TDS_Sensor::TDS_Sensor(byte pin) {
  this->pin = pin;
  init();
}

void TDS_Sensor::init() {
  pinMode(pin, INPUT);
}

float TDS_Sensor::getReading() {
  int sensorValue = analogRead(pin);
  float Voltage = sensorValue * 5 / 1024.0;
  float tdsValue = (133.42 / Voltage * Voltage * Voltage 
                    - 255.86 * Voltage * Voltage 
                    + 857.39 * Voltage) * 0.5;
  return tdsValue;
}

bool TDS_Sensor::isClean() {
  return getReading() < 300;
}

