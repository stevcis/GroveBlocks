#ifndef MY_TDS_SENSOR_H
#define MY_TDS_SENSOR_H
#include <Arduino.h>

class TDS_Sensor {
  
  private:
    byte pin;
    
  public:
    TDS_Sensor(byte pin);
    void init();
    float getReading();
    bool isClean();  // NEW method
};

#endif