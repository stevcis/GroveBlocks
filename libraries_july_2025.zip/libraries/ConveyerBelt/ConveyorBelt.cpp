#include "ConveyorBelt.h"

ConveyorBelt::ConveyorBelt() {
  Wire.begin();  // Initialize I2C
}

void ConveyorBelt::set_conveyor_belt(int direction, uint8_t speed) {
  if (speed > 100) speed = 100;  // Clamp speed to 100
  uint8_t message;
  if (direction == 1) {
    message = 100 + speed;
  } else if (direction == -1) {
    message = 100 - speed;
  } else {
    return;  // Invalid direction; do nothing
  }

  Wire.beginTransmission(_address);
  Wire.write(message);
  Wire.endTransmission();
}

void ConveyorBelt::stop_conveyor_belt() {
  Wire.beginTransmission(_address);
  Wire.write(100);  // Send stop command
  Wire.endTransmission();
}
