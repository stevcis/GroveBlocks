#ifndef ConveyorBelt_h
#define ConveyorBelt_h

#include <Wire.h>

class ConveyorBelt {
public:
  ConveyorBelt();  // No parameters needed for instantiation
  void set_conveyor_belt(int direction, uint8_t speed);
  void stop_conveyor_belt();

private:
  const uint8_t _address = 0x05;  // Hardcoded I2C address
};

#endif
