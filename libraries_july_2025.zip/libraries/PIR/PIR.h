#ifndef MY_PIR_H
#define MY_PIR_H
#include <Arduino.h>
class PIR {
  
  private:
    byte pin;
    
  public:
    PIR(byte pin);
    void init();
    float getReading();
};
#endif