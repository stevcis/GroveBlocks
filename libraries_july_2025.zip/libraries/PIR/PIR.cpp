#include "PIR.h"
PIR::PIR(byte pin) {
  this->pin = pin;
  init();
}

void PIR::init() {
  pinMode(pin, INPUT);
}

float PIR::getReading() {
	int sensor_value = digitalRead(pin);
    return sensor_value;
}
