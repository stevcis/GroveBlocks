#include "RainSensor.h"

RainSensor::RainSensor(byte pin) {
  this->pin = pin;
  init();   // automatically sets pinMode
}

void RainSensor::init() {
  pinMode(pin, INPUT);
}

bool RainSensor::iswet() {
  return digitalRead(pin) == LOW;
}
