#ifndef MY_RAINSENSOR_H
#define MY_RAINSENSOR_H

#include <Arduino.h>

class RainSensor {
  
  private:
    byte pin;
    
  public:
    RainSensor(byte pin);
    void init();            // optional, internal
    bool iswet();           // returns true if rain is detected (LOW)
};

#endif
