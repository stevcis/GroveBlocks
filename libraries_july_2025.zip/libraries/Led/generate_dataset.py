import os
import json

# Absolute paths for libraries and prompts
libraries_dir = "/Users/sfrancis/Documents/Arduino/libraries/"
prompts_dir = "/Users/sfrancis/Documents/Arduino/prompts/"
os.makedirs(prompts_dir, exist_ok=True)  # Ensure the Prompts directory exists
output_file = os.path.join(prompts_dir, "libraries_dataset.jsonl")

# Function to create dataset entries
def create_dataset(library_name, h_file, cpp_file, example_usage):
    with open(h_file, 'r') as h:
        h_content = h.read()
    with open(cpp_file, 'r') as cpp:
        cpp_content = cpp.read()

    dataset = []

    # Entry for listing methods
    dataset.append({
        "prompt": f"What methods are available in the {library_name} library?",
        "completion": f"Here is the implementation of the {library_name} library:\n\n**{library_name}.h**:\n{h_content}\n\n**{library_name}.cpp**:\n{cpp_content}"
    })

    # Entry for usage example
    dataset.append({
        "prompt": f"Write an Arduino program to use the {library_name} library.",
        "completion": example_usage
    })

    return dataset

# Manually written example usage for each library
usage_examples = {
    "Led": """#include "Led.h"

Led myLed(13);

void setup() {}

void loop() {
    myLed.on();
    delay(1000);
    myLed.off();
    delay(1000);
}""",

    "Buzzer": """//Add Libraries
#include "Buzzer.h"

//Add Variables

//Add Objects
Buzzer buzzer1(3);

//Main setup
void setup() {}

//Main Loop
void loop() {
    buzzer1.beep();
    delay(1000);
}""",

    "Button": """//Add Libraries
#include "Button.h"

//Add Variables

//Add Objects
Button button1(4);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    if (button1.isPressed()) {
        Serial.println("Pressed");
        delay(500);
    }
}""",

    "Recorder": """//Add Libraries
#include "Recorder.h"
#include "Button.h"

//Add Variables

//Add Objects
Recorder playback_speaker1(4,3);
Button button1(8);
Button button2(7);

//Main setup
void setup() {}

//Main Loop
void loop() {
    if (button1.isPressed()) {
        playback_speaker1.play();
        delay(1000);
    } else if (button2.isPressed()) {
        playback_speaker1.start_recording();
        while (button2.isPressed()) {
            delay(10);
        }
        playback_speaker1.end_recording();
    }
}""",

    "Heater": """//Add Libraries
#include "Heater.h"
#include "Led.h"

//Add Variables

//Add Objects
Heater heater1(7);
Led led1(8);

//Main setup
void setup() {}

//Main Loop
void loop() {
    heater1.on();
    led1.on();
    delay(60000);
    heater1.off();
    led1.off();
}""",

    "Pump": """//Add Libraries
#include "Pump.h"
#include "Button.h"

//Add Variables

//Add Objects
Pump pump1(7);
Button button1(4);

//Main setup
void setup() {}

//Main Loop
void loop() {
    if (button1.isPressed()) {
        pump1.on();
    } else {
        pump1.off();
    }
}""",

    "DCMotor": """//Add Libraries
#include "DCMotor.h"

//Add Variables

//Add Objects
DCMotor fan1(3);

//Main setup
void setup() {}

//Main Loop
void loop() {
    fan1.on();
    delay(5000);
    fan1.off();
    delay(5000);
}""",

    "RGB_LCD": """//Add Libraries
#include <Wire.h>
#include "rgb_lcd.h"

//Add Variables

//Add Objects
rgb_lcd screen;

//Main setup
void setup() {
    screen.begin(16,2);
    screen.clear();
    screen.setRGB(0,255,0);
    screen.print("Hello");
    screen.setCursor(0,1);
    screen.print("World");
}

//Main Loop
void loop() {}
""",

    "Atomiser": """//Add Libraries
#include "Atomiser.h"

//Add Variables

//Add Objects
Atomiser atomiser1(8);

//Main setup
void setup() {}

//Main Loop
void loop() {
    atomiser1.on();
    delay(30000);
    atomiser1.off();
    delay(30000);
}""",

    "Blower": """//Add Libraries
#include "Blower.h"

//Add Variables

//Add Objects
Blower blower1(7);

//Main setup
void setup() {}

//Main Loop
void loop() {
    blower1.on();
    delay(5000);
    blower1.off();
    delay(5000);
}""",

    "LightSensor": """//Add Libraries
#include "LightSensor.h"

//Add Variables
int light_level = 0;

//Add Objects
LightSensor light_sensor1(A0);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    light_level = light_sensor1.getReading();
    Serial.print("Light Level: ");
    Serial.println(light_level);
    delay(1000);
}""",

    "TemperatureSensor": """//Add Libraries
#include "TemperatureSensor.h"

//Add Variables
int temperature = 0;

//Add Objects
TemperatureSensor temp_sensor1(A0);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    temperature = temp_sensor1.getReading();
    Serial.print("The Temperature is: ");
    Serial.print(temperature);
    Serial.println(" degrees");
    delay(1000);
}""",

    "WindSpeedSensor": """//Add Libraries
#include "WindSpeedSensor.h"

//Add Variables
int wind_speed = 0;

//Add Objects
WindSpeedSensor wind_sensor1(A0);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    wind_speed = wind_sensor1.getReading();
    Serial.print("Wind Speed is: ");
    Serial.println(wind_speed);
    delay(3000);
}""",

    "RotaryAngleSensor": """//Add Libraries
#include "RotaryAngleSensor.h"

//Add Variables
int angle = 0;

//Add Objects
RotaryAngleSensor angle_sensor1(A0);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    angle = angle_sensor1.getReading();
    Serial.print("Angle (degrees): ");
    Serial.println(angle_sensor1.getReading());
    delay(500);
}""",

    "Ultrasonic": """//Add Libraries
#include "Ultrasonic.h"

//Add Variables
int distance = 0;

//Add Objects
Ultrasonic dist_sensor1(6);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    distance = dist_sensor1.MeasureInCentimeters();
    Serial.print("Distance: ");
    Serial.print(dist_sensor1.MeasureInCentimeters());
    Serial.println(" cm");
    delay(1000);
}""",

    "SoilMoistureSensor": """//Add Libraries
#include "SoilMoistureSensor.h"

//Add Variables
int soil_moisture_level = 0;

//Add Objects
SoilMoistureSensor soil_sensor1(A0);

//Main setup
void setup() {}

//Main Loop
void loop() {
    soil_moisture_level = soil_sensor1.getReading();
    Serial.print("Soil Moisture Level: ");
    Serial.println(soil_moisture_level);
    delay(1000);
}""",

    "SoundSensor": """//Add Libraries
#include "SoundSensor.h"

//Add Variables
int sound_level = 0;

//Add Objects
SoundSensor sound_sensor1(A0);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    sound_level = sound_sensor1.getReading();
    Serial.print("Sound Level: ");
    Serial.println(sound_level);
    delay(1000);
}""",

    "PIR": """//Add Libraries
#include "PIR.h"
#include "Led.h"

//Add Variables

//Add Objects
PIR pir1(7);
Led led1(4);

//Main setup
void setup() {}

//Main Loop
void loop() {
    if (pir1.checkForMotion()) {
        led1.on();
        delay(3000);
        led1.off();
    }
    delay(50);
}""",

    "DS18B20": """//Add Libraries
#include <DS18B20.h>

//Add Variables
int water_temp = 0;

//Add Objects
DS18B20 water_temp1(8);

//Main setup
void setup() {
    Serial.begin(9600);
}

//Main Loop
void loop() {
    water_temp = water_temp1.getTempC();
    Serial.print("The water temperature is ");
    Serial.print(water_temp);
    Serial.println(" degrees Celsius");
    delay(1000);
}""",

"Grove_I2C_Motor_Driver.h": """//Add Libraries
#include "Grove_I2C_Motor_Driver.h"

//Add Variables

//Add Objects

//Main setup
void setup() {
    Motor.begin(0x0f);
}

//Main Loop
void loop() {
    // Go forward for 1 second at full speed
    Motor.speed(MOTOR1, 100);
    Motor.speed(MOTOR2, 100);
    delay(2000);
    // Stop for 2 seconds
    Motor.stop(MOTOR1);
    Motor.stop(MOTOR2);
    delay(1000);
    // Go backwards for 1 second at half speed
    Motor.speed(MOTOR1, -50);
    Motor.speed(MOTOR2, -50);
    delay(1000);
    // Turn left (given MOTOR1 is left) for 1 second
    Motor.speed(MOTOR1, 100);
    Motor.speed(MOTOR2, -100);
    delay(1000);
}"""
}

# Process each library
with open(output_file, 'w') as f:
    for library_name, example_usage in usage_examples.items():
        h_file = os.path.join(libraries_dir, f"{library_name}.h")
        cpp_file = os.path.join(libraries_dir, f"{library_name}.cpp")
        if os.path.exists(h_file) and os.path.exists(cpp_file):
            dataset = create_dataset(library_name, h_file, cpp_file, example_usage)
            for entry in dataset:
                f.write(json.dumps(entry) + '\n')

print(f"Dataset saved to {output_file}")