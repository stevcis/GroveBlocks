#include "RFID.h"

RFID::RFID(uint8_t rx, uint8_t tx) : _ss(rx, tx), _buffer("") {}

void RFID::begin(uint32_t baud) {
  _ss.begin(baud);
}

bool RFID::available() {
  // Attempt to read an RFID code if data is available
  if (_ss.available()) {
    _buffer = "";
    unsigned long startTime = millis();
    while ((millis() - startTime < 100) && _ss.available()) {
      char c = _ss.read();
      _buffer += c;
      delay(2);  // optional: helps gather the full string
    }
    _buffer.trim();
    return true;
  }
  return false;
}

String RFID::get_code() {
  String clean = _buffer;
  clean.trim();

  if (clean.length() >= 2 && clean[0] == 0x02 && clean[clean.length() - 1] == 0x03) {
    clean = clean.substring(1, clean.length() - 1);  // Remove STX and ETX
  }

  return clean;
}
