#ifndef _RFID_H_
#define _RFID_H_

#include <Arduino.h>
#include <SoftwareSerial.h>

class RFID {
public:
  RFID(uint8_t rx, uint8_t tx);
  void begin(uint32_t baud = 9600);

  bool available();         // check if a new tag is detected
  String get_code();        // return the last scanned tag

private:
  SoftwareSerial _ss;
  String _buffer;
};

#endif
