#include "DCMotor.h"
DCMotor::DCMotor(byte pin) {
  // Use 'this->' to make the difference between the
  // 'pin' attribute of the class and the 
  // local variable 'pin' created from the parameter.
  this->pin = pin;
  init();
}
void DCMotor::init() {
  pinMode(pin, OUTPUT);
  // Always try to avoid duplicate code.
  // Instead of writing digitalWrite(pin, LOW) here,
  // call the function off() which already does that
  powerAnalog = 255;
  lastPower = 255;
  off();
}
void DCMotor::on() {
  if (powerAnalog == 0) {
    powerAnalog = lastPower;
  }
  analogWrite(pin, powerAnalog);
}
void DCMotor::off() {
  analogWrite(pin, 0);
}

void DCMotor::setPower(int powerSetting) {
  if (powerSetting == 1) {
    powerAnalog = 15;
    lastPower = 15;
  }
  else if (powerSetting == 2) {
    powerAnalog = 155;
    lastPower = 155;
  }
  else if (powerSetting == 3) {
    powerAnalog = 255;
    lastPower = 255;
  }
  else {
    powerAnalog = 0;
  }
  on();
}
