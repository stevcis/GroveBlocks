#ifndef MY_DCMotor_H
#define MY_DCMotor_H
#include <Arduino.h>
class DCMotor {
  
  private:
    byte pin;
    int powerAnalog;
    int lastPower;
    
  public:
    DCMotor(byte pin);
    void init();
    void on();
    void off();
    void setPower(int powerSetting);
};
#endif