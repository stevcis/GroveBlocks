#include "co2Sensor.h"
#include "SCD30.h"
#include <Wire.h>

co2Sensor::co2Sensor() {}

void co2Sensor::begin() {
  Wire.begin();
  scd30.initialize();
}

float co2Sensor::getReading() {
  return scd30.getCO2();
}
