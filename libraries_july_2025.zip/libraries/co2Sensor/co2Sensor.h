#ifndef CO2SENSOR_H
#define CO2SENSOR_H

#include <Arduino.h>

class co2Sensor {
  public:
    co2Sensor();
    void begin();
    float getReading();
};

#endif
