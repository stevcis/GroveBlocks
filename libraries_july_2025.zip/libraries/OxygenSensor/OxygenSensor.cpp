#include "OxygenSensor.h"
OxygenSensor::OxygenSensor(byte O2_pin) {
  this->O2_pin = O2_pin;
  init();
}

void OxygenSensor::init() {
  pinMode(O2_pin, INPUT);
  O2_preheat_time = 60000;
  O2_init_flag = 0;
  calibration_voltage = 3.3;
  O2_percentage = 20.80;
}

float OxygenSensor::getReading() {
	unsigned int sum = 0;
	for (unsigned char i = 32;i > 0;i--)
	{
		sum = sum + analogRead(O2_pin);
		delay(50);
	}
	sum = sum >> 5;
	//SerialUSB.println(sum);
	float output = sum / calibration_voltage;
	//SerialUSB.println(sum);
	return output;
}

void OxygenSensor::calibrate(float O2_actual) {
	O2_percentage = O2_actual;
	unsigned int sum = 0;
	for (unsigned char i = 64;i > 0;i--)
	{
		sum = sum + analogRead(O2_pin);
		delay(100);
	}
	sum = sum >> 6;
	calibration_voltage = sum / O2_percentage;
}
