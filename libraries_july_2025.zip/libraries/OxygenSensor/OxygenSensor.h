#ifndef MY_OXYGENSENSOR_H
#define MY_OXYGENSENSOR_H
#include <Arduino.h>
class OxygenSensor {
  
  private:
    byte O2_pin;
    float calibration_voltage;
    int O2_preheat_time;
    bool O2_init_flag;
    float O2_percentage;
    
  public:
    OxygenSensor(byte pin);
    void init();
    void calibrate(float O2_actual);
    float getReading();
};
#endif
