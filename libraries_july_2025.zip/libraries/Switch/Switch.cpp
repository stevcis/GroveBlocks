#include "Switch.h"

Switch::Switch(byte pin) {
  this->pin = pin;
  init();
}

void Switch::init() {
  pinMode(pin, INPUT);
}

bool Switch::isUp() {
  return digitalRead(pin) == HIGH;
}

bool Switch::isDown() {
  return digitalRead(pin) == LOW;
}