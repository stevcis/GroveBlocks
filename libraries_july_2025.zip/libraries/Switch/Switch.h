#ifndef GROVE_SWITCH_H
#define GROVE_SWITCH_H

#include <Arduino.h>

class Switch {
  private:
    byte pin;

  public:
    Switch(byte pin);
    void init();
    bool isUp();
    bool isDown();
};

#endif
