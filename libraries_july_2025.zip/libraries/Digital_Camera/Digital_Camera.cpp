#include "Digital_Camera.h"

Digital_Camera::Digital_Camera() {
    init(); // Initialize the I2C communication
}

void Digital_Camera::init() {
  Wire.begin();
}


void Digital_Camera::switch_to_live_mode() {
    Wire.beginTransmission(9);
    Wire.write('l');
    Wire.endTransmission();
    delay(1000);
}

void Digital_Camera::switch_to_view_mode() {
    Wire.beginTransmission(9);
    Wire.write('v');
    Wire.endTransmission();
    delay(1000);
}

void Digital_Camera::next_photo() {
    Wire.beginTransmission(9);
    Wire.write('t');
    Wire.endTransmission();
    delay(500);
}

void Digital_Camera::previous_photo() {
    Wire.beginTransmission(9);
    Wire.write('p');
    Wire.endTransmission();
    delay(500);
}

void Digital_Camera::take_photo() {
    Wire.beginTransmission(9);
    Wire.write('n');
    Wire.endTransmission();
    delay(2000);
}

void Digital_Camera::clear_SD_memory() {
    Wire.beginTransmission(9);
    Wire.write('c');
    Wire.endTransmission();
    delay(5000);
}