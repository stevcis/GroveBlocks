#ifndef DIGITAL_CAMERA_H
#define DIGITAL_CAMERA_H
#include <Arduino.h>
#include <Wire.h>

class Digital_Camera {
	public:
	    Digital_Camera();
	    
	    void init();
	    void switch_to_live_mode();
	    void switch_to_view_mode();
	    void next_photo();
	    void previous_photo();
	    void take_photo();
	    void clear_SD_memory();

	private:
	    static const uint8_t slaveAddress = 9;
};

#endif  