#ifndef MY_BUZZER_H
#define MY_BUZZER_H
#include <Arduino.h>
class Buzzer {
  
  private:
    byte pin;
    int buzzerTempo;
    int noteDelay;
    
  public:
    Buzzer(byte pin);
    void init();
    void off();
    void on();
    void beep();
    void shortBeep();
    void longBeep();
    void tripleBeep();
    void setTempo(int newTempo);
    void setNoteDelay(int newNoteDelay);
    void playNote(int tone, int noteType);
};
#endif