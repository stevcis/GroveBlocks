#include "Buzzer.h"
#include "pitches.h"

Buzzer::Buzzer(byte pin) {
  this->pin = pin;
  init();
}
void Buzzer::init() {
  pinMode(pin, OUTPUT);
  buzzerTempo = 2000;
  noteDelay = 50;
  off();
}

void Buzzer::off() {
  digitalWrite(pin, LOW);
}

void Buzzer::on() {
  digitalWrite(pin, HIGH);
}

void Buzzer::beep() {
  digitalWrite(pin, HIGH);
  delay(500);
  digitalWrite(pin, LOW);
}

void Buzzer::shortBeep() {
  digitalWrite(pin, HIGH);
  delay(150);
  digitalWrite(pin, LOW);
}

void Buzzer::longBeep() {
  digitalWrite(pin, HIGH);
  delay(1000);
  digitalWrite(pin, LOW);
}

void Buzzer::tripleBeep() {
  digitalWrite(pin, HIGH);
  delay(150);
  digitalWrite(pin, LOW);
  delay(30);
  digitalWrite(pin, HIGH);
  delay(150);
  digitalWrite(pin, LOW);
  delay(30);
  digitalWrite(pin, HIGH);
  delay(150);
  digitalWrite(pin, LOW);
}

void Buzzer::setTempo(int newTempo) {
  buzzerTempo = newTempo;
}

void Buzzer::setNoteDelay(int newNoteDelay) {
  noteDelay = newNoteDelay;
}


void Buzzer::playNote(int frequency, int noteType) {
    // Calculate note duration based on tempo (whole note = buzzerTempo ms)
    int duration = buzzerTempo / noteType;  // Adjust for quarter, half, etc.

    // Play the note for the calculated duration
    tone(pin, frequency, duration);

    // Delay to allow the note to be heard
    delay(duration + noteDelay);  

    // Stop the tone to create separation between notes
    noTone(pin);
}


