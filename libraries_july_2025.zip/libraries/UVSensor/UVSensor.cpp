#include "UVSensor.h"
#include <math.h>

UVSensor::UVSensor(byte pin) {
  this->pin = pin;
  init();
}

void UVSensor::init() {
  pinMode(pin, INPUT);
}

float UVSensor::getReading() {
	int sensorValue;
    int  sum=0;
    for(int i=0;i<1024;i++)// accumulate readings for 1024 times
    {
        sensorValue=analogRead(pin);
        sum=sensorValue+sum;
        delay(2);
    }
     float meanVal = sum/1024;  // get mean value
     float v = meanVal * 4.89; // convert to voltage
     float uvi = v*0.01-1.3;
     if (uvi > 0) {
     	return uvi;
     }
     else {
     	return 0.0;
     }

}