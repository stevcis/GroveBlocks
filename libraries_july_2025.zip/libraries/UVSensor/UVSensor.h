#ifndef MY_UVSENSOR_H
#define MY_UVSENSOR_H
#include <Arduino.h>
class UVSensor {
  
  private:
    byte pin;
    
  public:
    UVSensor(byte pin);
    void init();
    float getReading();
};
#endif