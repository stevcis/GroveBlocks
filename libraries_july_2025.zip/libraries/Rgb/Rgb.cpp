#include "Led.h"
Rgb::Rgb(int redPin, int greenPin, int bluePin) {
  // Use 'this->' to make the difference between the
  // 'pin' attribute of the class and the 
  // local variable 'pin' created from the parameter.
  this->redPin = redPin;
  this->greenPin = greenPin;
  this->bluePin = bluePin;
  init();
}
void Rgb::init() {
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
  // Always try to avoid duplicate code.
  // Instead of writing digitalWrite(pin, LOW) here,
  // call the function off() which already does that
  off();
}
void Rgb::on() {
  analogWrite(redPin, 255);
  analogWrite(greenPin, 255);
  analogWrite(BluePin, 255);
}
void Rgb::off() {
  analogWrite(redPin, 0);
  analogWrite(greenPin, 0);
  analogWrite(BluePin, 0);
}
void Rgb::red() {
  analogWrite(redPin, 255);
  analogWrite(greenPin, 0);
  analogWrite(BluePin, 0);
}
void Rgb::blue() {
  analogWrite(redPin, 0);
  analogWrite(greenPin, 0);
  analogWrite(BluePin, 255);
}
void Rgb::green() {
  analogWrite(redPin, 0);
  analogWrite(greenPin, 255);
  analogWrite(BluePin, 0);
}
void Rgb::magenta() {
  analogWrite(redPin, 255);
  analogWrite(greenPin, 0);
  analogWrite(BluePin, 255);
}
void Rgb::yellow() {
  analogWrite(redPin, 255);
  analogWrite(greenPin, 255);
  analogWrite(BluePin, 0);
}
void Rgb::cyan() {
  analogWrite(redPin, 0);
  analogWrite(greenPin, 255);
  analogWrite(BluePin, 255);
}
void Rgb::orange() {
  analogWrite(redPin, 200);
  analogWrite(greenPin, 100);
  analogWrite(BluePin, 0);
}
void Rgb::setColour(int redValue, int greenValue, int blueValue) {
  analogWrite(redPin, redValue);
  analogWrite(greenPin, greenValue);
  analogWrite(BluePin, blueValue);
}