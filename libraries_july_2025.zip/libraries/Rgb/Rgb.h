#ifndef MY_LED_H
#define MY_LED_H
#include <Arduino.h>
class Rgb {
  
  private:
    int redPin;
   	int greenPin;
   	int bluePin;
    
  public:
    Rgb(int redPin, int greenPin, int bluePin);
    void init();
    void off();
    void red();
    void blue();
    void green();
    void magenta();
    void yellow();
    void cyan();
    void orange();
    void purple();
    void setColour(int redValue, int greenValue, int blueValue);
};
#endif