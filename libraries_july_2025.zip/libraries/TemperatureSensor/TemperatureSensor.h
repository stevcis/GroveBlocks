#ifndef MY_TEMPERATURESENSOR_H
#define MY_TEMPERATURESENSOR_H
#include <Arduino.h>
class TemperatureSensor {
  
  private:
    byte pin;
    
  public:
    TemperatureSensor(byte pin);
    void init();
    float getReading();
};
#endif