#include "TemperatureSensor.h"
#include <math.h>

TemperatureSensor::TemperatureSensor(byte pin) {
  this->pin = pin;
  init();
}

void TemperatureSensor::init() {
  pinMode(pin, INPUT);
}

float TemperatureSensor::getReading() {
	int sensor_value = analogRead(pin);
	float resistance=(float)(1023-sensor_value)*10000/sensor_value;
    float temperature=1/(log(resistance/10000)/3975+1/298.15)-273.15;
    return temperature;
}