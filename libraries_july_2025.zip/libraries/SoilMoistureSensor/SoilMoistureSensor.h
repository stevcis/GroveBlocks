#ifndef MY_SOILMOISTURESENSOR_H
#define MY_SOILMOISTURESENSOR_H
#include <Arduino.h>
class SoilMoistureSensor {
  
  private:
    byte pin;
    
  public:
    SoilMoistureSensor(byte pin);
    void init();
    float getReading();
};
#endif