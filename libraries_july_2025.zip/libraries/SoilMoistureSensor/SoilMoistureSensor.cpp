#include "SoilMoistureSensor.h"
#include <math.h>

SoilMoistureSensor::SoilMoistureSensor(byte pin) {
  this->pin = pin;
  init();
}

void SoilMoistureSensor::init() {
  pinMode(pin, INPUT);
}

float SoilMoistureSensor::getReading() {
	int sensorValue = analogRead(pin);
    return sensorValue;
}