#ifndef MY_PUMP_H
#define MY_PUMP_H
#include <Arduino.h>
class Pump {
  
  private:
    byte pin;
    
  public:
    Pump(byte pin);
    void init();
    void on();
    void off();
};
#endif