#ifndef MY_ROTARYANGLESENSOR_H
#define MY_ROTARYANGLESENSOR_H
#include <Arduino.h>
class RotaryAngleSensor {
  
  private:
    byte pin;
    
  public:
    RotaryAngleSensor(byte pin);
    void init();
    float getReading();
};
#endif