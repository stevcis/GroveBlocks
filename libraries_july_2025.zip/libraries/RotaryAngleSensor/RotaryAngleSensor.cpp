#include "RotaryAngleSensor.h"
RotaryAngleSensor::RotaryAngleSensor(byte pin) {
  this->pin = pin;
  init();
}

void RotaryAngleSensor::init() {
  pinMode(pin, INPUT);
}

float RotaryAngleSensor::getReading() {
	int sensor_value = analogRead(pin);
	float voltage = (float)sensor_value*5/1023;
    float degrees = (voltage*300)/5;
    return degrees;
}


