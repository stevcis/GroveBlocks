#include "Recorder.h"
Recorder::Recorder(byte r_pin, byte p_pin) {
  // Use 'this->' to make the difference between the
  // 'pin' attribute of the class and the 
  // local variable 'pin' created from the parameter.
  this->r_pin = r_pin;
  this->p_pin = p_pin;
  init();
}
void Recorder::init() {
  pinMode(r_pin, OUTPUT);
  pinMode(p_pin, OUTPUT);
  // Always try to avoid duplicate code.
  // Instead of writing digitalWrite(pin, LOW) here,
  // call the function off() which already does that
  digitalWrite(r_pin, HIGH);
  digitalWrite(p_pin, HIGH);
}
void Recorder::end_recording() {
  digitalWrite(r_pin, HIGH);
}
void Recorder::start_recording() {
  digitalWrite(r_pin, LOW);
}
void Recorder::play() {
  digitalWrite(p_pin, LOW);
  delay(100);
  digitalWrite(p_pin, HIGH);
}