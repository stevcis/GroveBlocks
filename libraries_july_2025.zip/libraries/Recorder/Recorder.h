#ifndef MY_RECORDER_H
#define MY_RECORDER_H
#include <Arduino.h>
class Recorder {
  
  private:
    byte r_pin;
    byte p_pin;
    
  public:
    Recorder(byte r_pin, byte p_pin);
    void init();
    void start_recording();
    void end_recording();
    void play();
};
#endif